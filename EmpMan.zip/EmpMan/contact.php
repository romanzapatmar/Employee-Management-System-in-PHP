<?php include('nav.php');?>

<!-- connection insert query -->
<?php 
include('conn.php');

if (isset($_POST['submit'])) {

  $com_ments = mysqli_real_escape_string($con, $_REQUEST['comments']);
 

  $sql = "INSERT INTO `comments` (`comments`) VALUES ('$com_ments')";

  // echo $sql;

  $result = mysqli_query($con, $sql);

  if (!isset($result)) {
    echo "Not inserted!".mysqli_query_error();
  }
  // else{
  //   echo "Inserted successfully!";
  // }
if ($result) {
  echo "<script>
  alert('Comment success!');
  </script>";
}
}

?>
<!-- insert query -->

<?php 
session_start();

 ?>
 
<?php 
if (isset($_SESSION["id"])) {

 ?>
 
 <!-- <center><p>Welcome <b><?php echo $_SESSION["firstname"]; ?> <?php echo $_SESSION["lastname"]; ?>.</b></p>
 
 <button id="log"><a href="logout.php">Logout</a></button></center><br> -->

 <div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <h4>Free to Join</h4>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="#section1">Home</a></li>
        <!-- <li><a href="#section2">Friends</a></li>
        <li><a href="#section3">Family</a></li>
        <li><a href="#section3">Photos</a></li> -->
      </ul><br>
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search Blog..">
        <span class="input-group-btn">
          <button class="btn btn-default" type="button">
            <span class="glyphicon glyphicon-search"></span>
          </button>
        </span>
      </div><br>
      <div class="container">
  <!-- <h2>Simple Collapsible</h2> -->
  <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">Click to contact</button>
  <div id="demo" class="collapse">
   feel always free to ask <br>
  <?php echo"&#128222";?> 07122-55142 <br>
  <?php echo"&#9993";?> emprecsys@gmail.com
  </div>
</div>
    </div>
    <!-- yha se -->
    

    <div class="col-sm-9">
      <h4><small>RECENT POSTS</small></h4>
        <hr>
          <h2>I Love this Site</h2>
          <h5><span class="glyphicon glyphicon-time"></span> Post by Rishikesh Landekar, April 15, 2021.</h5>
          <h5><span class="label label-danger">Software Development</span> <span class="label label-primary">Website Development</span></h5><br>
          <p>Hello Guys! I am searching for the job on internet then i find this site, and it was very helpful and I got job with the help of this site, Thank you Employee Recruitment System</p>
          <br><br>
      
      <h4><small>RECENT POSTS</small></h4>
        <hr>
      <h2>Official Comment</h2>
          <h5><span class="glyphicon glyphicon-time"></span> Post by Priti Netam, April 17, 2021.</h5>
          <h5><span class="label label-success">Comment</span></h5><br>
          <p>Hello, Welcome to our Website, I hope this will very helpful for all of us, who need information about IT Technologies and who wants job in that field, I will recommend about this site that from they can get best of polular sites, so please visit our website, Thank you!!!</p>
        <hr>

      <h4>Leave a Comment:</h4>
<form role="form" method="POST" action="">
    <div class="form-group">
        <textarea name="comments" class="form-control" id="comments" cols="3" required></textarea>
        </div>
        <button  type="submit" class="btn btn-success" name="submit" id="submit">Submit</button>
      </form>
      <br><br>

      <!-- <input type="text" class="form-control" id="comments" name="comments" required=""> -->
    
      <p><span class="badge">2</span> Comments:</p><br>
      
      <div class="row">
        <div class="col-sm-2 text-center">
          <img src="image/arti.jpg" class="img-circle" height="65" width="65" alt="">
        </div>
        <div class="col-sm-10">
          <h4>Arti Gajbhiye <?php echo "\u{1F60D}"; ?> <small>April 17, 2021, 9:12 PM</small></h4>
          <p>Keep it up the GREAT work! I am cheering for you!! This is amezing website, and very helpful for youngsters.</p>
          <br>
        </div>
        <div class="col-sm-2 text-center">
          <img src="image/vedi.jpg" class="img-circle" height="65" width="65" alt="">
        </div>
        <div class="col-sm-10">
          <h4>Vedika Doye <?php echo "\u{1F60D}"; ?> <small>April 16, 2021, 8:25 PM</small></h4>
          <p>I am very thank to this site, it help me so much for job. Thank You Employee Recruitment System.</p>
          <br>
          <p><span class="badge">1</span> Comment:</p><br>
          <div class="row">
            <div class="col-sm-2 text-center">
              <img src="image/mam.jpg" class="img-circle" height="65" width="65" alt="">
            </div>
            <div class="col-xs-10">
              <h4>Shraddha Gawalkar <small>April 16, 2021, 8:28 PM</small></h4>
              <p>Keep going... Congratulations!!! <?php echo" &#127881, &#127882";?></p>
              <br>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php include('footer.php');?>

<?php 
}

?>