                                  *******Thank You for Visiting*********

                     -----Welcome to Online Employee Recruitment System in Python-------

                                 Make a DB on XAMPP name it- empman
 Create Table 1. tblemp (tablename)
		****make column****
		1. id(int100) Primary Key (AI)
		2. name (VARCHAR100)
		3. email (VARCHAR100)
		4. password (VARCHAR100)
		5. Pword (VARCHAR100)
		
           2. comments (tablename)
		****make column****
		1. id(int50) Primary Key (AI)
		2. comments (VARCHAR100)
  
                                              *********Login with********
                                                 ID : admin@gmail.com
                                                 Password : admin

		