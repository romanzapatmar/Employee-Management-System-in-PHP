<center><h6>@All copyrights are reserved</h6></center>
</body>
</html>