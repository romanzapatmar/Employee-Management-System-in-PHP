<?php include('nav.php');?>
<?php 
session_start();

 ?>
 
<?php 
if (isset($_SESSION["id"])) {

 ?>
 
 <!-- <center><p>Welcome <b><?php echo $_SESSION["firstname"]; ?> <?php echo $_SESSION["lastname"]; ?>.</b></p>
 
 <button id="log"><a href="logout.php">Logout</a></button></center><br> -->


<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
        <h4>Follow us</h4>
      <p><a href="https://www.facebook.com/">Facebook</a></p>
      <p><a href="https://www.instagram.com/accounts/login/">Instagram</a></p>
      <p><a href="https://ads.twitter.com/">Twitter</a></p>
    </div>
    <div class="col-sm-8 text-left"> 
      <h1>About us</h1>
      <p>Hello guys! Thanks for visiting our site, we are the polytechnic final year student from Computer Engineering Department, And this our Final Project Which we are done under the guidance of Mis. P.S. Netam (H.O.D). We are glad to thanks all our group members who support us to complete this project and other teachers also who always able to support us.</p>
      <hr>
      <h3>About project...</h3>
      <p>This is a project based on Employee Recruitment System which is developed in Python Language which will help to find a job for yougsters who studyng in the IT or any other field. We are a Final Year Student of Computer Engineering Department (Polytechnic) from C. S. Institute of Technology, Deori</p>
    </div>
    <!-- Advertise1 -->
    <div class="col-sm-2 sidenav">
      <!-- Bootstrap carousual -->
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
    <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="image/csit.jpg" alt="">
    </div>

    <div class="item">
      <img src="image/ad7.jpg" alt="">
    </div>

    <div class="item">
      <img src="image/ad8.jpg" alt="">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
      <!-- Bootstrap carousual -->
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
    <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="image/ad9.jpg" alt="">
    </div>

    <div class="item">
      <img src="image/ad10.jpg" alt="">
    </div>

    <div class="item">
      <img src="image/ad11.jpg" alt="">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
    </div>
  </div>
</div>
<!-- images -->
<div class="container">
  <center><h4> <b> A Project Developed by</b></h4></center>
  <center><p>Department of Computer Engineering <?php echo" &#127891";?></center>
  <div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="/w3images/lights.jpg" target="_blank">
          <img src="image/arti.jpg" alt="Lights" style="width:100%">
          <div class="caption">
          <p>Name: Mis. Arti Devkumar Gajbhiye <br> Enrollment No.: 1911910120 <br> Email ID: gajbhiyearti52@gmail.com <br> Mobile No.: 9307208751</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="/w3images/nature.jpg" target="_blank">
          <img src="image/rishi.jpg" alt="Nature" style="width:80%">
          <div class="caption">
            <p>Name: Mr. Rushikesh Sanjay Landekar<br> Enrollment No.: 1911910123 <br> Email ID: hrishilandekar007@gmail.com <br> Mobile No.: 7768036179</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="/w3images/fjords.jpg" target="_blank">
          <img src="image/vedi.jpg" alt="Fjords" style="width:100%">
          <div class="caption">
            <p>Name: Mis. Vedika Devidas Doye <br> Enrollment No.: 1911910122 <br> Email ID: vedikadoye44@gmail.com <br> Mobile No.: 7030687847</p>
          </div>
        </a>
      </div>
    </div>
  </div>
</div>
<!-- images -->
<?php include('footer.php');?>

<?php 
}

?>
