<?php include('nav.php');?>
<?php 
    include('conn.php');
    session_start();

if (isset($_POST['submit'])) {
  
        $sql = "SELECT * FROM `tblemp` WHERE email='" . $_POST['email'] . "' AND Pword = MD5('". $_POST['Pword']."')";
  
        $result = mysqli_query($con, $sql);

        $row = mysqli_fetch_assoc($result);

if (is_array($row))
{
        $_SESSION["id"] = $row["id"];
        $_SESSION["firstname"] = $row["firstname"];
        $_SESSION["lastname"] = $row["lastname"];
}
else
{
        echo "<script>alert('Invalid username or password!')</script>";
}

}
if (isset($_SESSION["id"]))
{
    header("Location:home.php");
}
?>
<form class="my-4" action="" method="POST">
<div class="container">
    
        <div class="col-md-4">
              <label for="inputEmail4" class="form-label">Email</label>
              <input type="email" class="form-control" id="inputEmail4" name="email">
          </div> 
          <br>
          <br>
          <br>
      
        <div class="col-md-4">
            <label for="inputPassword4" class="form-label">Password</label>
            <input type="password" class="form-control" id="inputPassword4" name="Pword">
        </div>
        <br>
        <br>
        <br>
        <div class="col-12">
            <button type="submit" class="btn btn-primary" name="submit">Sign In</button>&nbsp;<p>If you not having account? Please <a href="signup.php">Sign Up</a></p>
        </div>
    </div>
</form>

<div class="container">
  <center><h4>Welcome</h4></center>
  <center><p>Find the best job here...</p></center>
  <div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="/w3images/lights.jpg" target="_blank">
          <img src="image/sc1.jpg" alt="Lights" style="width:100%">
          <div class="caption">
            <!-- <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p> -->
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="/w3images/nature.jpg" target="_blank">
          <img src="image/sc7.jpg" alt="Nature" style="width:100%">
          <div class="caption">
            <!-- <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p> -->
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="/w3images/fjords.jpg" target="_blank">
          <img src="image/sc5.jpg" alt="Fjords" style="width:100%">
          <div class="caption">
            <!-- <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p> -->
          </div>
        </a>
      </div>
    </div>
  </div>
</div>



<?php include('footer.php');?>

