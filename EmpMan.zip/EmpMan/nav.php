<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/home.css">
<link rel="stylesheet" type="text/css" href="css/login.css">
<link rel="stylesheet" type="text/css" href="css/contact.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Recruitment System</title>
    <link rel = "icon" href ="image/ic.png" type = "image/x-icon">
  
</head>
<body>
    <nav>
        <div class="nav">
            <ul class="nav nav-tabs">
                <li class="a" class="active"><a href="login.php">Login/Signup</a></li>
                <li><a href="home.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <div id="img"><img src="image/icon.png" alt=""></div>
            </ul>
        </div>
        <marquee id="mar" behavior="reverse" direction="">Online Employee Recruitment System in Python</marquee>
        <!-- <img id="img" src="image/backimg.jpg" alt=""> -->
</nav>
